from django.contrib import admin
from .models import *

admin.site.register(PizzaTopping)
admin.site.register(PizzaType)
admin.site.register(Pizza)
admin.site.register(SubType)
admin.site.register(Sub)
admin.site.register(SaladType)
admin.site.register(Salad)
admin.site.register(PastaType)
admin.site.register(Pasta)
admin.site.register(PlatterType)
admin.site.register(Platter)
admin.site.register(ProperOrder)