from django.contrib import admin
from django.urls import path
from website.views import home,register,user_login,user_logout,cart_view, menu_view, add_to_cart, make_order, all_orders_view, mark_order_as_done, user_orders_view, clear_cart, fill_menu,productlist_view


urlpatterns = [
    path('home/',home),
    path('register/',register),
    path('user_login/',user_login),
    path('user_logout/',user_logout),
    path("cart/",cart_view ),
    path("menu/", menu_view),
    path("add/<str:item_type>/<int:item_id>/<str:item_bigger>/<int:add_cheese>", add_to_cart, name="add_to_cart"),
    path("finalize/", make_order),
    path("all_orders/", all_orders_view),
    path("order/<int:order_id>/done", mark_order_as_done, name="mark_order_as_done"),
    path("my_orders/", user_orders_view),
    path("clear_cart/", clear_cart),
    path("fill_menu/", fill_menu),
    path('product_list/',productlist_view )


]