from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
from django.db.models.signals import post_save
import decimal
# Create your models here.

class UserProfileInfo(models.Model):
    user = models.OneToOneField(User,on_delete = models.CASCADE)


    def __str__(self):
        return self.username



class ProperOrder(models.Model):
    order_client = models.ForeignKey(User, on_delete=models.CASCADE)
    order_timestamp = models.DateTimeField(auto_now_add=True)
    order_price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00, editable=False)
    order_done = models.BooleanField(default=False)

    def __str__(self):
        return f"Order number {self.id}"
#Appetizer
class AppetizerType(models.Model):
    name = models.CharField(max_length=60, unique=True)
    price = models.DecimalField(max_digits=4, decimal_places=2, default=0.00)

    def __str__(self):
        return self.name


class Appetizer(models.Model):
    in_order = models.ForeignKey(ProperOrder, on_delete=models.CASCADE, null=True, related_name="Appetizer")
    already_ordered = models.BooleanField(default=False)
    add_by = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    appetizertype = models.ForeignKey(AppetizerType, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=4, decimal_places=2, default=0.00, editable=False)

    def calculate_price(self):
        self.price = self.appetizertype.price

    def __str__(self):
        return f"Appetizer: {str(self.appetizertype)}"


#Entree
class EntreeType(models.Model):
    name = models.CharField(max_length=60, unique=True)
    price = models.DecimalField(max_digits=4, decimal_places=2, default=0.00)

    def __str__(self):
        return self.name


class Entree(models.Model):
    in_order = models.ForeignKey(ProperOrder, on_delete=models.CASCADE, null=True, related_name="entree")
    already_ordered = models.BooleanField(default=False)
    add_by = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    entreetype = models.ForeignKey(EntreeType, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=4, decimal_places=2, default=0.00, editable=False)

    def calculate_price(self):
        self.price = self.entreetype.price

    def __str__(self):
        return f"Entree: {str(self.entreetype)}"


#Dessert
class DessertType(models.Model):
    name = models.CharField(max_length=60, unique=True)
    price = models.DecimalField(max_digits=4, decimal_places=2, default=0.00)

    def __str__(self):
        return self.name


class Dessert(models.Model):
    in_order = models.ForeignKey(ProperOrder, on_delete=models.CASCADE, null=True, related_name="desserts")
    already_ordered = models.BooleanField(default=False)
    add_by = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    desserttype = models.ForeignKey(DessertType, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=4, decimal_places=2, default=0.00, editable=False)

    def calculate_price(self):
        self.price = self.desserttype.price

    def __str__(self):
        return f"Dessert: {str(self.desserttype)}"
