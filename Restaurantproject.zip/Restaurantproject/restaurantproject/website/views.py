from django.shortcuts import render,redirect
from .forms import UserForm,UserProfileInfoForm
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponseRedirect,HttpResponse

from django.contrib.auth.decorators import login_required
from .models import *
from django.contrib.admin.views.decorators import staff_member_required


# Create your views here.
def home(request):
    return render(request, "home.html", None)




@login_required
def user_logout(request):
    logout(request)
    return redirect (("http://localhost:8000/website/home/"))


def register(request):

    registered = False

    if request.method =="POST":
        user_form = UserForm(data=request.POST)
        profile_form = UserProfileInfoForm(data=request.POST)

        if user_form.is_valid() :
            user=user_form.save()
            user.set_password(user.password)
            user.save()

        registered = True

    else:
        user_form = UserForm()
        profile_form = UserProfileInfoForm()

    return render(request,'register.html',{'user_form':user_form,'profile_form':profile_form,'registered':registered} )




def user_login(request):

    if request.method=='POST':
        usernme = request.POST.get('username')
        passwrd= request.POST.get('password')

        user = authenticate(username=usernme, password=passwrd)

        if user:
            if user.is_active:
                login(request,user)
                return redirect(("http://localhost:8000/website/home/"))

            else:
                return redirect("http://localhost:8000/website/user_login/")
        else:
            print("Someone tried to login and failed!")
            print("Username: {} and password {}". format(username,password))
            return HttpResponse("invalid login details supplied!")
    else:
        return render(request,'login.html',{})

def delete_all_user_orders(username):
    Appetizer.objects.filter(add_by=username).filter(already_ordered=False).delete()
    Entree.objects.filter(add_by=username).filter(already_ordered=False).delete()
    Dessert.objects.filter(add_by=username).filter(already_ordered=False).delete()

    return True


def calculate_cart_price(username):
    price_all = 0

    for obj in Appetizer.objects.filter(add_by=username).filter(already_ordered=False):
        price_all += obj.price
    for obj in Entree.objects.filter(add_by=username).filter(already_ordered=False):
        price_all += obj.price
    for obj in Dessert.objects.filter(add_by=username).filter(already_ordered=False):
        price_all += obj.price

    return price_all


@login_required
def cart_view(request):
    price_all = Decimal(calculate_cart_price(request.user))
    context = {}
    context.update({"price_all": price_all})
    context.update({"Appetizer": Pasta.objects.filter(add_by=request.user).filter(already_ordered=False)})
    context.update({"Entree": Salad.objects.filter(add_by=request.user).filter(already_ordered=False)})
    context.update({"Dessert": Platter.objects.filter(add_by=request.user).filter(already_ordered=False)})


    return render(request, 'cart.html')


@login_required()
def menu_view(request):


    context = {}

    context.update({"Appetizer": AppetizerType.objects.all()})
    context.update({"Entree": EntreeType.objects.all()})
    context.update({"Dessert": DessertType.objects.all()})

    return render(request, 'menu.html', context)


@login_required()
def add_to_cart(request, item_type, item_id):



    if item_type == "Appetizer":
        item_id = AppetizerType.objects.get(id=item_id)
        new_appetizer = Appetizer(appetizertype=item_id, add_by=request.user)
        new_appetizer.calculate_price()
        new_appetizer.save()
        messages.add_message(request, messages.INFO, "Appetizer added!")

    elif item_type == "Entree":
        item_id = EntreeType.objects.get(id=item_id)
        new_entree = Entree(entreetype=item_id, add_by=request.user)
        new_entree.calculate_price()
        new_entree.save()
        messages.add_message(request, messages.INFO, "Entree added!")

    elif item_type == "Dessert":
        item_id = DessertType.objects.get(id=item_id)
        new_dessert = Dessert(desserttype=item_id, add_by=request.user)
        new_dessert.calculate_price()
        new_dessert.save()
        messages.add_message(request, messages.INFO, "Dessert added!")

    else:
        return HttpResponseNotFound('<h1>Product not found</h1>')

    return redirect("http://localhost:8000/website/menu/")


@login_required()
def make_order(request):
    new_proper_order = ProperOrder()
    new_proper_order.order_client = request.user
    new_proper_order.order_price = calculate_cart_price(request.user)
    new_proper_order.save()



    for item in Appetizer.objects.filter(add_by=request.user).filter(already_ordered=False):
        item.already_ordered = True
        item.in_order = new_proper_order
        item.save()

    for item in Entree.objects.filter(add_by=request.user).filter(already_ordered=False):
        item.already_ordered = True
        item.in_order = new_proper_order
        item.save()

    for item in Dessert.objects.filter(add_by=request.user).filter(already_ordered=False):
        item.already_ordered = True
        item.in_order = new_proper_order
        item.save()



    messages.add_message(request, messages.INFO, f"Order number {new_proper_order.id} send! If you have questions, contact us: 617-876-4897")
    return redirect("http://localhost:8000/website/orderonline/")


@staff_member_required
def all_orders_view(request):
    context = {"orders": reversed(ProperOrder.objects.all())}
    return render(request, 'all_orders.html', context)


@login_required
def user_orders_view(request):
    context = {"orders": reversed(ProperOrder.objects.filter(order_client=request.user))}
    return render(request, 'my_orders.html', context)


@staff_member_required
def mark_order_as_done(request, order_id):
    marked = ProperOrder.objects.get(id=order_id)
    marked.order_done = True
    marked.save()
    return redirect("http://localhost:8000/website/all_orders/")


@login_required
def clear_cart(request):
    delete_all_user_orders(request.user)
    return redirect("cart_view")


@staff_member_required()
def fill_menu(request):
    add_menu()
    return redirect("http://localhost:8000/website/home/")



def productlist_view(request):
    return render (request,"product_list_page.html", None)




