from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(UserProfileInfo)
admin.site.register(AppetizerType)
admin.site.register(Appetizer)
admin.site.register(EntreeType)
admin.site.register(Entree)
admin.site.register(DessertType)
admin.site.register(Dessert)
admin.site.register(ProperOrder)